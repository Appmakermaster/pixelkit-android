// Firebase is intentionally optional in the current PixelKit build.
// Add Firebase configuration here only when cloud features are enabled.
export default null;
