import { Link } from "react-router-dom";

export default function Projects() {
  return (
    <main style={{ maxWidth: 900, margin: "0 auto", padding: 24 }}>
      <h1>My Projects</h1>
      <p>Projects are stored locally in this browser.</p>
      <p>
        Open the editor to create and save a PixelKit project.
      </p>
      <Link to="/editor">
        <button type="button">Open Editor</button>
      </Link>
    </main>
  );
}
