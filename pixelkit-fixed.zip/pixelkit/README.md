# PixelKit

PixelKit is a React photo editor packaged for Android with Capacitor.

## Local web build

```bash
npm install
npm run build
```

## Android

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

The debug APK is generated at:

`android/app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

The workflow at `.github/workflows/build-android.yml` builds the React app, creates/syncs the Capacitor Android project, builds the debug APK, and uploads it as a workflow artifact.
