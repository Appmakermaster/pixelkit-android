export default function LayerPanel({
  objects = [],
  selectedIndex = null,
  onSelect,
}) {
  return (
    <div className="layer-panel">
      <h3>Layers</h3>

      {objects.length === 0 ? (
        <div className="layer-empty">No layers yet</div>
      ) : (
        objects
          .slice()
          .reverse()
          .map((object, reversedIndex) => {
            const index = objects.length - 1 - reversedIndex;

            return (
              <div
                key={index}
                className={`layer-item ${
                  selectedIndex === index ? "selected" : ""
                }`}
                onClick={() => {
                  if (onSelect) {
                    onSelect(index);
                  }
                }}
              >
                <span className="layer-number">{index + 1}</span>

                <span className="layer-name">
                  {object.name || `${object.type || "Object"} ${index + 1}`}
                </span>
              </div>
            );
          })
      )}
    </div>
  );
}
