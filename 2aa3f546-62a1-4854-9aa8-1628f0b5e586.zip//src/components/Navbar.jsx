import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <div
      style={{
        display: "flex",
        gap: 20,
        padding: 20,
        background: "#111827",
        color: "white",
      }}
    >
      <Link
        to="/"
        style={{
          color: "white",
          textDecoration: "none",
        }}
      >
        Home
      </Link>

      <Link
        to="/editor"
        style={{
          color: "white",
          textDecoration: "none",
        }}
      >
        Editor
      </Link>

      <Link
        to="/projects"
        style={{
          color: "white",
          textDecoration: "none",
        }}
      >
        Projects
      </Link>
    </div>
  );
}
