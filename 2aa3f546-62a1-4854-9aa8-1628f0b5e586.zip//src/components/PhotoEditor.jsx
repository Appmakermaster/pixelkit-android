import { useEffect, useRef, useState } from "react";
import "./PhotoEditor.css";

import {
  Canvas,
  Rect,
  Circle,
  Triangle,
  IText,
  FabricImage,
  PencilBrush,
  filters,
  Shadow,
  Gradient,
} from "fabric";
import LayerPanel from "./LayerPanel";
import useUndoRedo from "../hooks/useUndoRedo";

export default function PhotoEditor() {
  const canvasRef = useRef(null);
  const fabricRef = useRef(null);

  const [layers, setLayers] = useState([]);
  const [textColor, setTextColor] = useState("#000000");
  const [canvasColor, setCanvasColor] = useState("#ffffff");
  const [drawingMode, setDrawingMode] = useState(false);
  const [brushColor, setBrushColor] = useState("#000000");
  const [brushWidth, setBrushWidth] = useState(5);
  const [opacity, setOpacity] = useState(100);
  const [fontSize, setFontSize] = useState(30);
  const [fontFamily, setFontFamily] = useState("Arial");
  const [brightness, setBrightness] = useState(0);
  const [contrast, setContrast] = useState(0);
  const [saturation, setSaturation] = useState(0);
  const [blur, setBlur] = useState(0);
  const [cropMode, setCropMode] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [strokeWidth, setStrokeWidth] = useState(0);
  const [objectColor, setObjectColor] = useState("#ff0000");
  const [showHelp, setShowHelp] = useState(false);
  const [customWidth, setCustomWidth] = useState(1080);
  const [customHeight, setCustomHeight] = useState(1080);
  const [cropRect, setCropRect] = useState(null);
  const [selectedLayer, setSelectedLayer] = useState(null);
  const [multiSelect, setMultiSelect] = useState(false);
  const [selectedLayerIndex, setSelectedLayerIndex] = useState(null);

  const { saveState, undo, redo } = useUndoRedo();

  useEffect(() => {
    const element = canvasRef.current;

    if (!element) return;

    const canvas = new Canvas(element, {
      width: 900,
      height: 600,
      backgroundColor: "#ffffff",
    });

    canvas.freeDrawingBrush = new PencilBrush(canvas);

    fabricRef.current = canvas;

    const autoSave = () => {
      try {
        const json = canvas.toJSON();

        localStorage.setItem("pixelkit-autosave", JSON.stringify(json));
      } catch (error) {
        console.error("Autosave error:", error);
      }
    };

    const autoSaveTimer = setInterval(autoSave, 10000);

    saveState(canvas);

    const updateSelection = () => {
      const activeObject = canvas.getActiveObject();

      setSelectedLayer(activeObject);

      if (activeObject) {
        const index = canvas.getObjects().indexOf(activeObject);
        setSelectedLayerIndex(index);
      } else {
        setSelectedLayerIndex(null);
      }

      setLayers([...canvas.getObjects()]);
    };

    const clearSelection = () => {
      setSelectedLayer(null);
      setSelectedLayerIndex(null);
    };

    canvas.on("selection:created", updateSelection);
    canvas.on("selection:updated", updateSelection);
    canvas.on("selection:cleared", clearSelection);

    const updateLayers = () => {
      const objects = canvas.getObjects();

      setLayers([...objects]);

      const activeObject = canvas.getActiveObject();

      if (activeObject) {
        const index = objects.indexOf(activeObject);

        setSelectedLayer(activeObject);
        setSelectedLayerIndex(index);
      } else {
        setSelectedLayer(null);
        setSelectedLayerIndex(null);
      }
    };

    const handleObjectAdded = () => {
      updateLayers();
      saveState(canvas);
    };

    const handleObjectRemoved = () => {
      updateLayers();
      saveState(canvas);
    };

    const handleObjectModified = () => {
      updateLayers();
      saveState(canvas);
    };

    canvas.on("object:added", handleObjectAdded);
    canvas.on("object:removed", handleObjectRemoved);
    canvas.on("object:modified", handleObjectModified);

    return () => {
      clearInterval(autoSaveTimer);

      canvas.off("selection:created", updateSelection);
      canvas.off("selection:updated", updateSelection);
      canvas.off("selection:cleared", clearSelection);

      canvas.off("object:added", handleObjectAdded);
      canvas.off("object:removed", handleObjectRemoved);
      canvas.off("object:modified", handleObjectModified);

      if (fabricRef.current === canvas) {
        fabricRef.current = null;
      }

      canvas.dispose();
    };
  }, [saveState]);

  useEffect(() => {
    const handleKey = (e) => {
      const canvas = fabricRef.current;

      if (!canvas) return;

      if (e.key === "Delete") {
        const selected = canvas.getActiveObject();

        if (selected) {
          canvas.remove(selected);
        }
      }

      if (e.ctrlKey && e.key.toLowerCase() === "z") {
        e.preventDefault();
        undo(canvas);
      }

      if (e.ctrlKey && e.key.toLowerCase() === "y") {
        e.preventDefault();
        redo(canvas);
      }
    };

    window.addEventListener("keydown", handleKey);

    return () => window.removeEventListener("keydown", handleKey);
  }, [undo, redo]);

  const addRectangle = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Canvas is not ready.");
      return;
    }

    const rect = new Rect({
      left: 100,
      top: 100,
      width: 150,
      height: 100,
      fill: "#3b82f6",
    });

    canvas.add(rect);
    canvas.setActiveObject(rect);
    canvas.renderAll();
  };

  const addCircle = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Canvas is not ready.");
      return;
    }

    const circle = new Circle({
      radius: 50,
      left: 150,
      top: 150,
      fill: "#ff0000",
    });

    canvas.add(circle);
    canvas.setActiveObject(circle);
    canvas.renderAll();
  };

  const addTriangle = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Canvas is not ready.");
      return;
    }

    const triangle = new Triangle({
      width: 100,
      height: 100,
      fill: "#22c55e",
      left: 200,
      top: 200,
    });

    canvas.add(triangle);
    canvas.setActiveObject(triangle);
    canvas.renderAll();
  };

  const addText = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Canvas is not ready.");
      return;
    }

    const text = new IText("PixelKit Text", {
      left: 150,
      top: 150,
      fontSize: 30,
      fill: textColor,
    });

    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.renderAll();
  }; // <-- IMPORTANT

  const deleteSelected = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const selected = canvas.getActiveObject();

    if (!selected) {
      alert("Select an object first.");
      return;
    }

    canvas.remove(selected);
    canvas.discardActiveObject();
    canvas.renderAll();
  };

  const rotateSelected = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Select an object first.");
      return;
    }

    obj.rotate((obj.angle || 0) + 15);
    obj.setCoords();

    canvas.renderAll();
  };

  const bringForward = () => {
    const obj = fabricRef.current.getActiveObject();

    if (!obj) return;

    fabricRef.current.bringObjectForward(obj);

    fabricRef.current.renderAll();
  };

  const sendBackward = () => {
    const obj = fabricRef.current.getActiveObject();

    if (!obj) return;

    fabricRef.current.sendObjectBackwards(obj);

    fabricRef.current.renderAll();
  };

  const zoomIn = () => {
    const canvas = fabricRef.current;
    canvas.setZoom(canvas.getZoom() * 1.1);
  };

  const zoomOut = () => {
    const canvas = fabricRef.current;
    canvas.setZoom(canvas.getZoom() * 0.9);
  };

  const downloadFile = (dataURL, filename) => {
    const link = document.createElement("a");
    link.href = dataURL;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportPNG = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Editor is not ready.");
      return;
    }

    const dataURL = canvas.toDataURL({
      format: "png",
      multiplier: 1,
    });

    downloadFile(dataURL, "pixelkit.png");
  };

  const exportJPG = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Editor is not ready.");
      return;
    }

    const dataURL = canvas.toDataURL({
      format: "jpeg",
      quality: 1,
      multiplier: 1,
    });

    downloadFile(dataURL, "pixelkit.jpg");
  };

  const exportWEBP = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Editor is not ready.");
      return;
    }

    const dataURL = canvas.toDataURL({
      format: "webp",
      quality: 1,
      multiplier: 1,
    });

    downloadFile(dataURL, "pixelkit.webp");
  };

  const loadProject = async () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Editor is not ready.");
      return;
    }

    const json = localStorage.getItem("pixelkit-project");

    if (!json) {
      alert("No saved project found.");
      return;
    }

    try {
      await canvas.loadFromJSON(JSON.parse(json));

      canvas.discardActiveObject();

      setLayers([...canvas.getObjects()]);
      setSelectedLayer(null);
      setSelectedLayerIndex(null);

      canvas.requestRenderAll();

      alert("Project loaded successfully!");
    } catch (error) {
      console.error("Load project error:", error);
      alert("Could not load project.");
    }
  };

  const loadAutosave = async () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Editor is not ready.");
      return;
    }

    const json = localStorage.getItem("pixelkit-autosave");

    if (!json) {
      alert("No autosaved project found.");
      return;
    }

    try {
      await canvas.loadFromJSON(JSON.parse(json));

      canvas.discardActiveObject();

      setLayers([...canvas.getObjects()]);
      setSelectedLayer(null);
      setSelectedLayerIndex(null);

      canvas.requestRenderAll();

      alert("Autosaved project loaded!");
    } catch (error) {
      console.error("Autosave load error:", error);
      alert("Could not load autosaved project.");
    }
  };

  const getSelectedImage = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Editor is not ready.");
      return null;
    }

    const object = canvas.getActiveObject();

    if (!object || object.type !== "image") {
      alert("Please select an image first.");
      return null;
    }

    return object;
  };

  const applyGrayscale = () => {
    const image = getSelectedImage();

    if (!image) return;

    image.filters = [new filters.Grayscale()];

    image.applyFilters();

    fabricRef.current.requestRenderAll();
  };

  const applySepia = () => {
    const image = getSelectedImage();

    if (!image) return;

    image.filters = [new filters.Sepia()];

    image.applyFilters();

    fabricRef.current.requestRenderAll();
  };

  const applyInvert = () => {
    const image = getSelectedImage();

    if (!image) return;

    image.filters = [new filters.Invert()];

    image.applyFilters();

    fabricRef.current.requestRenderAll();
  };

  const clearFilters = () => {
    const canvas = fabricRef.current;
    if (!canvas) return;

    const image = canvas.getActiveObject();

    if (!image || image.type !== "image") {
      alert("Please select an image first.");
      return;
    }

    image.filters = [];
    image.applyFilters();

    setBrightness(0);
    setContrast(0);
    setSaturation(0);
    setBlur(0);

    canvas.requestRenderAll();
  };

  const toggleDrawingMode = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Editor is not ready.");
      return;
    }

    if (!canvas.freeDrawingBrush) {
      canvas.freeDrawingBrush = new PencilBrush(canvas);
    }

    canvas.isDrawingMode = !canvas.isDrawingMode;

    canvas.freeDrawingBrush.color = brushColor;
    canvas.freeDrawingBrush.width = Number(brushWidth);

    setDrawingMode(canvas.isDrawingMode);

    canvas.requestRenderAll();
  };

  const changeOpacity = (value) => {
    setOpacity(value);

    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) return;

    obj.set("opacity", Number(value) / 100);

    canvas.requestRenderAll();
  };

  const changeFontSize = (value) => {
    setFontSize(value);

    const obj = fabricRef.current.getActiveObject();

    if (!obj || obj.type !== "i-text") return;

    obj.set("fontSize", value);

    fabricRef.current.renderAll();
  };

  const changeFontFamily = (font) => {
    setFontFamily(font);

    const obj = fabricRef.current.getActiveObject();

    if (!obj || obj.type !== "i-text") return;

    obj.set("fontFamily", font);

    fabricRef.current.renderAll();
  };

  const changeTextColor = (color) => {
    setTextColor(color);

    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj || obj.type !== "i-text") {
      alert("Please select a text object first.");
      return;
    }

    obj.set("fill", color);

    canvas.requestRenderAll();
  };

  const updateImageFilters = ({
    brightnessValue = brightness,
    contrastValue = contrast,
    saturationValue = saturation,
    blurValue = blur,
  }) => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj || obj.type !== "image") {
      return;
    }

    obj.filters = [
      new filters.Brightness({
        brightness: Number(brightnessValue) / 100,
      }),

      new filters.Contrast({
        contrast: Number(contrastValue) / 100,
      }),

      new filters.Saturation({
        saturation: Number(saturationValue) / 100,
      }),

      new filters.Blur({
        blur: Number(blurValue) / 100,
      }),
    ];

    obj.applyFilters();
    canvas.requestRenderAll();
  };

  const changeBrightness = (value) => {
    setBrightness(value);

    updateImageFilters({
      brightnessValue: value,
    });
  };

  const changeContrast = (value) => {
    setContrast(value);

    updateImageFilters({
      contrastValue: value,
    });
  };

  const changeSaturation = (value) => {
    setSaturation(value);

    updateImageFilters({
      saturationValue: value,
    });
  };

  const changeBlur = (value) => {
    setBlur(value);

    updateImageFilters({
      blurValue: value,
    });
  };

  const flipHorizontal = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select an object first.");
      return;
    }

    obj.set("flipX", !obj.flipX);
    obj.setCoords();

    canvas.requestRenderAll();
  };

  const flipVertical = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select an object first.");
      return;
    }

    obj.set("flipY", !obj.flipY);
    obj.setCoords();

    canvas.requestRenderAll();
  };

  const duplicateSelected = async () => {
    const obj = fabricRef.current.getActiveObject();

    if (!obj) return;

    const clone = await obj.clone();

    clone.set({
      left: obj.left + 20,
      top: obj.top + 20,
    });

    fabricRef.current.add(clone);
    fabricRef.current.renderAll();
  };

  const toggleBold = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj || obj.type !== "i-text") {
      alert("Please select a text object first.");
      return;
    }

    obj.set("fontWeight", obj.fontWeight === "bold" ? "normal" : "bold");

    canvas.requestRenderAll();
  };

  const toggleItalic = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj || obj.type !== "i-text") {
      alert("Please select a text object first.");
      return;
    }

    obj.set("fontStyle", obj.fontStyle === "italic" ? "normal" : "italic");

    canvas.requestRenderAll();
  };
  const toggleUnderline = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj || obj.type !== "i-text") {
      alert("Please select a text object first.");
      return;
    }

    obj.set("underline", !obj.underline);

    canvas.requestRenderAll();
  };

  const addShadow = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select an object first.");
      return;
    }

    obj.set(
      "shadow",
      new Shadow({
        color: "rgba(0,0,0,0.5)",
        blur: 10,
        offsetX: 5,
        offsetY: 5,
      })
    );

    canvas.requestRenderAll();
  };

  const changeRotation = (value) => {
    setRotation(value);

    const obj = fabricRef.current.getActiveObject();

    if (!obj) return;

    obj.rotate(value);

    fabricRef.current.renderAll();
  };

  const changeStroke = (value) => {
    setStrokeWidth(value);

    const obj = fabricRef.current.getActiveObject();

    if (!obj) return;

    obj.set({
      stroke: "#000000",
      strokeWidth: value,
    });

    fabricRef.current.renderAll();
  };

  const setTextAlign = (align) => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj || obj.type !== "i-text") {
      alert("Please select a text object first.");
      return;
    }

    obj.set("textAlign", align);

    canvas.requestRenderAll();
  };

  const lockObject = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select an object first.");
      return;
    }

    obj.set({
      selectable: false,
      evented: false,
      lockMovementX: true,
      lockMovementY: true,
      lockScalingX: true,
      lockScalingY: true,
      lockRotation: true,
    });

    canvas.discardActiveObject();
    canvas.requestRenderAll();

    setLayers([...canvas.getObjects()]);
  };

  const unlockObject = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Select the locked object from the Layers panel first.");
      return;
    }

    obj.set({
      selectable: true,
      evented: true,
      lockMovementX: false,
      lockMovementY: false,
      lockScalingX: false,
      lockRotation: false,
    });

    canvas.setActiveObject(obj);
    canvas.requestRenderAll();

    setSelectedLayer(obj);
    setSelectedLayerIndex(canvas.getObjects().indexOf(obj));
  };

  const changeObjectColor = (color) => {
    setObjectColor(color);

    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select an object first.");
      return;
    }

    // Images use filters instead of fill
    if (obj.type === "image") {
      alert("Color cannot be directly applied to an image.");
      return;
    }

    obj.set("fill", color);
    canvas.requestRenderAll();
  };

  const duplicate5x = async () => {
    const obj = fabricRef.current.getActiveObject();

    if (!obj) return;

    for (let i = 1; i <= 5; i++) {
      const clone = await obj.clone();

      clone.set({
        left: obj.left + i * 30,
        top: obj.top + i * 30,
      });

      fabricRef.current.add(clone);
    }

    fabricRef.current.renderAll();
  };

  const clearCanvas = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    canvas.clear();

    canvas.backgroundColor = canvasColor;

    canvas.renderAll();

    setLayers([]);
    setSelectedLayer(null);
    setSelectedLayerIndex(null);
  };

  const exportTransparentPNG = () => {
    const canvas = fabricRef.current;

    const oldBg = canvas.backgroundColor;

    canvas.backgroundColor = null;

    canvas.renderAll();

    const dataURL = canvas.toDataURL({
      format: "png",
    });

    canvas.backgroundColor = oldBg;

    canvas.renderAll();

    const link = document.createElement("a");

    link.href = dataURL;

    link.download = "pixelkit-transparent.png";

    link.click();
  };

  const renameLayer = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select a layer first.");
      return;
    }

    const currentName = obj.name || obj.type || "Layer";

    const name = prompt("Enter layer name:", currentName);

    if (!name || !name.trim()) return;

    obj.name = name.trim();

    canvas.requestRenderAll();

    setLayers([...canvas.getObjects()]);
  };

  const hideObject = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select a layer first.");
      return;
    }

    obj.set("visible", false);

    canvas.discardActiveObject();
    canvas.requestRenderAll();

    setLayers([...canvas.getObjects()]);
  };

  const showAllObjects = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    canvas.getObjects().forEach((obj) => {
      obj.set("visible", true);
    });

    canvas.requestRenderAll();

    setLayers([...canvas.getObjects()]);
  };

  const addGradient = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select an object first.");
      return;
    }

    if (obj.type === "image" || obj.type === "i-text") {
      alert("Select a shape first.");
      return;
    }

    obj.set(
      "fill",
      new Gradient({
        type: "linear",
        coords: {
          x1: 0,
          y1: 0,
          x2: obj.width || 200,
          y2: 0,
        },
        colorStops: [
          { offset: 0, color: "#ff0000" },
          { offset: 1, color: "#0000ff" },
        ],
      })
    );

    canvas.requestRenderAll();
  };

  const addEmoji = () => {
    fabricRef.current.add(
      new IText("😀", {
        left: 100,
        top: 100,
        fontSize: 80,
      })
    );
  };

  const instagramSize = () => {
    fabricRef.current.setDimensions({
      width: 1080,
      height: 1080,
    });

    fabricRef.current.renderAll();
  };

  const youtubeSize = () => {
    fabricRef.current.setDimensions({
      width: 1280,
      height: 720,
    });

    fabricRef.current.renderAll();
  };

  const tiktokSize = () => {
    fabricRef.current.setDimensions({
      width: 1080,
      height: 1920,
    });

    fabricRef.current.renderAll();
  };

  const bringToFront = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select a layer first.");
      return;
    }

    canvas.bringObjectToFront(obj);

    canvas.requestRenderAll();

    setLayers([...canvas.getObjects()]);
  };

  const sendToBack = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const obj = canvas.getActiveObject();

    if (!obj) {
      alert("Please select a layer first.");
      return;
    }

    canvas.sendObjectToBack(obj);

    canvas.requestRenderAll();

    setLayers([...canvas.getObjects()]);
  };

  const customResize = () => {
    const w = parseInt(customWidth, 10);
    const h = parseInt(customHeight, 10);

    if (!w || !h) return;

    fabricRef.current.setDimensions({
      width: w,
      height: h,
    });

    fabricRef.current.renderAll();
  };

  const addSticker = (emoji) => {
    fabricRef.current.add(
      new IText(emoji, {
        left: 100,
        top: 100,
        fontSize: 100,
      })
    );
  };

  const youtubeTemplate = () => {
    clearCanvas();

    fabricRef.current.add(
      new Rect({
        width: 1280,
        height: 720,
        fill: "#111",
        left: 0,
        top: 0,
        selectable: false,
      })
    );

    fabricRef.current.add(
      new IText("YOUR TITLE", {
        left: 100,
        top: 250,
        fill: "white",
        fontSize: 80,
      })
    );
  };

  const startCrop = () => {
    const canvas = fabricRef.current;

    if (!canvas) return;

    const image = canvas.getActiveObject();

    if (!image || image.type !== "image") {
      alert("Please select an image first.");
      return;
    }

    const rect = new Rect({
      left: image.left - 100,
      top: image.top - 100,
      width: 200,
      height: 200,
      fill: "rgba(0,0,0,0.15)",
      stroke: "#ef4444",
      strokeWidth: 2,
      selectable: true,
      evented: true,
    });

    canvas.add(rect);
    canvas.setActiveObject(rect);

    setCropRect(rect);

    canvas.requestRenderAll();
  };

  const applyCrop = async () => {
    const image = fabricRef.current.getActiveObject();

    if (!image || image.type !== "image" || !cropRect) return;

    const cropped = await image.clone();

    cropped.set({
      left: cropRect.left,
      top: cropRect.top,
      cropX: (cropRect.left - image.left) / image.scaleX,

      cropY: (cropRect.top - image.top) / image.scaleY,
      width: cropRect.width,
      height: cropRect.height,
    });

    fabricRef.current.remove(image);
    fabricRef.current.add(cropped);
    fabricRef.current.remove(cropRect);

    setCropRect(null);

    fabricRef.current.renderAll();
  };

  const removeBackground = async () => {
    alert("Remove background feature disabled");
  };

  const uploadImage = async (e) => {
    const file = e.target.files?.[0];

    if (!file) return;

    if (!file.type.startsWith("image/")) {
      alert("Please select an image file.");
      return;
    }

    try {
      const reader = new FileReader();

      reader.onload = async () => {
        try {
          const image = await FabricImage.fromURL(reader.result);

          const canvas = fabricRef.current;

          if (!canvas) return;

          const maxWidth = canvas.getWidth() * 0.8;
          const maxHeight = canvas.getHeight() * 0.8;

          const scale = Math.min(
            maxWidth / image.width,
            maxHeight / image.height,
            1
          );

          image.set({
            left: canvas.getWidth() / 2,
            top: canvas.getHeight() / 2,
            originX: "center",
            originY: "center",
            scaleX: scale,
            scaleY: scale,
          });

          canvas.add(image);
          canvas.setActiveObject(image);
          canvas.renderAll();

          e.target.value = "";
        } catch (error) {
          console.error("Image loading error:", error);
          alert("Could not load this image.");
        }
      };

      reader.onerror = () => {
        alert("Could not read the image.");
      };

      reader.readAsDataURL(file);
    } catch (error) {
      console.error("Upload error:", error);
      alert("Image upload failed.");
    }
  };
  // Save project
  const saveProject = () => {
    const canvas = fabricRef.current;

    if (!canvas) {
      alert("Editor is not ready.");
      return;
    }

    try {
      const json = canvas.toJSON();

      localStorage.setItem("pixelkit-project", JSON.stringify(json));

      localStorage.setItem("pixelkit-autosave", JSON.stringify(json));

      alert("Project saved successfully!");
    } catch (error) {
      console.error("Save project error:", error);
      alert("Could not save project.");
    }
  };

  return (
    <div className="pixelkit-app">
      {showHelp && (
        <div className="help-panel">
          <h3>PixelKit Photo Editor</h3>

          <p>
            Upload an image, add shapes and text, apply filters, draw, resize
            and export your project.
          </p>

          <button onClick={() => setShowHelp(false)}>Close Help</button>
        </div>
      )}

      <div className="photo-editor">
        <div className="editor-toolbar">
          <button
            type="button"
            onClick={() => {
              const canvas = fabricRef.current;

              alert(
                canvas
                  ? `Canvas OK. Objects: ${canvas.getObjects().length}`
                  : "FABRIC CANVAS IS NULL"
              );

              if (!canvas) return;

              const rect = new Rect({
                left: 100,
                top: 100,
                width: 150,
                height: 100,
                fill: "red",
              });

              canvas.add(rect);
              canvas.setActiveObject(rect);
              canvas.requestRenderAll();

              alert(`Rectangle added. Objects: ${canvas.getObjects().length}`);
            }}
          >
            Rectangle
          </button>

          <button onClick={addCircle}>Circle</button>

          <button onClick={addTriangle}>Triangle</button>

          <button onClick={addText}>Text</button>

          <label>
            Upload Image
            <input type="file" accept="image/*" onChange={uploadImage} />
          </label>

          <button onClick={saveProject}>Save Project</button>

          <button onClick={loadProject}>Load Project</button>

          <button onClick={loadAutosave}>Load Autosave</button>

          <button onClick={exportPNG}>PNG</button>

          <button onClick={exportJPG}>JPG</button>

          <button onClick={exportWEBP}>WEBP</button>

          <button onClick={() => setShowHelp(!showHelp)}>Help</button>
        </div>

        <div className="editor-workspace">
          <div className="canvas-wrapper">
            <canvas ref={canvasRef} />
          </div>

          <LayerPanel
            objects={layers}
            selectedIndex={selectedLayerIndex}
            onSelect={(index) => {
              const canvas = fabricRef.current;

              if (!canvas) return;

              const objects = canvas.getObjects();
              const object = objects[index];

              if (!object) return;

              canvas.discardActiveObject();
              canvas.setActiveObject(object);

              setSelectedLayer(object);
              setSelectedLayerIndex(index);

              canvas.requestRenderAll();
            }}
          />
        </div>

        <div className="editor-controls">
          <button type="button" onClick={deleteSelected}>
            Delete
          </button>

          <button type="button" onClick={duplicateSelected}>
            Duplicate
          </button>

          <button type="button" onClick={rotateSelected}>
            Rotate
          </button>

          <button type="button" onClick={bringToFront}>
            Bring Front
          </button>

          <button type="button" onClick={sendToBack}>
            Send Back
          </button>

          <button
            type="button"
            onClick={() => {
              const canvas = fabricRef.current;

              if (!canvas) {
                alert("Editor is not ready.");
                return;
              }

              undo(canvas);

              setTimeout(() => {
                setLayers([...canvas.getObjects()]);
                canvas.requestRenderAll();
              }, 50);
            }}
          >
            Undo
          </button>

          <button
            type="button"
            onClick={() => {
              const canvas = fabricRef.current;

              if (!canvas) {
                alert("Editor is not ready.");
                return;
              }

              redo(canvas);

              setTimeout(() => {
                setLayers([...canvas.getObjects()]);
                canvas.requestRenderAll();
              }, 50);
            }}
          >
            Redo
          </button>

          <button onClick={toggleDrawingMode}>
            {drawingMode ? "Stop Drawing" : "Draw"}
          </button>

          <button onClick={clearCanvas}>Clear Canvas</button>

          <hr />

          <h3>Image Filters</h3>

          <label>
            Brightness: {brightness}
            <input
              type="range"
              min="-100"
              max="100"
              value={brightness}
              onChange={(e) => changeBrightness(Number(e.target.value))}
            />
          </label>

          <label>
            Contrast: {contrast}
            <input
              type="range"
              min="-100"
              max="100"
              value={contrast}
              onChange={(e) => changeContrast(Number(e.target.value))}
            />
          </label>

          <label>
            Saturation: {saturation}
            <input
              type="range"
              min="-100"
              max="100"
              value={saturation}
              onChange={(e) => changeSaturation(Number(e.target.value))}
            />
          </label>

          <label>
            Blur: {blur}
            <input
              type="range"
              min="0"
              max="100"
              value={blur}
              onChange={(e) => changeBlur(Number(e.target.value))}
            />
          </label>

          <button onClick={applyGrayscale}>Grayscale</button>

          <button onClick={applySepia}>Sepia</button>

          <button onClick={applyInvert}>Invert</button>

          <button onClick={clearFilters}>Clear Filters</button>

          <hr />

          <h3>Object</h3>

          <button onClick={flipHorizontal}>Flip H</button>

          <button onClick={flipVertical}>Flip V</button>

          <button onClick={addShadow}>Shadow</button>

          <button onClick={addGradient}>Gradient</button>

          <button onClick={lockObject}>Lock</button>

          <button onClick={unlockObject}>Unlock</button>

          <button onClick={hideObject}>Hide</button>

          <button onClick={showAllObjects}>Show All</button>

          <button onClick={renameLayer}>Rename Layer</button>

          <hr />

          <h3>Text</h3>

          <label>
            Text Color
            <input
              type="color"
              value={textColor}
              onChange={(e) => changeTextColor(e.target.value)}
            />
          </label>

          <button onClick={toggleBold}>Bold</button>

          <button onClick={toggleItalic}>Italic</button>

          <button onClick={toggleUnderline}>Underline</button>

          <button onClick={() => setTextAlign("left")}>Left</button>

          <button onClick={() => setTextAlign("center")}>Center</button>

          <button onClick={() => setTextAlign("right")}>Right</button>

          <label>
            Font Size
            <input
              type="range"
              min="10"
              max="150"
              value={fontSize}
              onChange={(e) => changeFontSize(Number(e.target.value))}
            />
          </label>

          <select
            value={fontFamily}
            onChange={(e) => changeFontFamily(e.target.value)}
          >
            <option value="Arial">Arial</option>
            <option value="Verdana">Verdana</option>
            <option value="Georgia">Georgia</option>
            <option value="Times New Roman">Times New Roman</option>
            <option value="Courier New">Courier New</option>
          </select>

          <hr />

          <h3>Opacity</h3>

          <input
            type="range"
            min="0"
            max="100"
            value={opacity}
            onChange={(e) => changeOpacity(Number(e.target.value))}
          />

          <hr />

          <h3>Canvas Size</h3>

          <button onClick={instagramSize}>Instagram</button>

          <button onClick={youtubeSize}>YouTube</button>

          <button onClick={tiktokSize}>TikTok</button>

          <div>
            <input
              type="number"
              value={customWidth}
              onChange={(e) => setCustomWidth(e.target.value)}
              placeholder="Width"
            />

            <input
              type="number"
              value={customHeight}
              onChange={(e) => setCustomHeight(e.target.value)}
              placeholder="Height"
            />

            <button onClick={customResize}>Resize</button>
          </div>

          <hr />

          <h3>Stickers</h3>

          <button onClick={() => addSticker("😀")}>😀</button>
          <button onClick={() => addSticker("❤️")}>❤️</button>
          <button onClick={() => addSticker("🔥")}>🔥</button>
          <button onClick={() => addSticker("⭐")}>⭐</button>
          <button onClick={() => addSticker("😂")}>😂</button>

          <hr />

          <h3>Export</h3>

          <button onClick={exportTransparentPNG}>Transparent PNG</button>

          <hr />

          <h3>Templates</h3>

          <button onClick={youtubeTemplate}>YouTube Template</button>
        </div>
      </div>
    </div>
  );
}
