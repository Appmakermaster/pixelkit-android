import { useCallback, useRef } from "react";

export default function useUndoRedo() {
  const historyRef = useRef([]);
  const redoRef = useRef([]);
  const restoringRef = useRef(false);

  const saveState = useCallback((canvas) => {
    if (!canvas || restoringRef.current) return;

    const json = JSON.stringify(canvas.toJSON());

    const history = historyRef.current;

    // Don't save identical consecutive states
    if (history.length > 0) {
      const lastState = history[history.length - 1];

      if (lastState === json) {
        return;
      }
    }

    history.push(json);

    // Keep history manageable
    if (history.length > 50) {
      history.shift();
    }

    // A new change removes the redo history
    redoRef.current = [];
  }, []);

  const restoreState = useCallback(async (canvas, json) => {
    if (!canvas || !json) return;

    restoringRef.current = true;

    try {
      await canvas.loadFromJSON(JSON.parse(json));
      canvas.discardActiveObject();
      canvas.requestRenderAll();
    } catch (error) {
      console.error("History restore error:", error);
    } finally {
      restoringRef.current = false;
    }
  }, []);

  const undo = useCallback(
    async (canvas) => {
      if (!canvas) return;

      const history = historyRef.current;

      // Need at least the current state + previous state
      if (history.length <= 1) {
        return;
      }

      const currentState = history.pop();

      redoRef.current.push(currentState);

      const previousState = history[history.length - 1];

      await restoreState(canvas, previousState);
    },
    [restoreState]
  );

  const redo = useCallback(
    async (canvas) => {
      if (!canvas) return;

      const redoHistory = redoRef.current;

      if (redoHistory.length === 0) {
        return;
      }

      const nextState = redoHistory.pop();

      historyRef.current.push(nextState);

      await restoreState(canvas, nextState);
    },
    [restoreState]
  );

  return {
    saveState,
    undo,
    redo,
  };
}
