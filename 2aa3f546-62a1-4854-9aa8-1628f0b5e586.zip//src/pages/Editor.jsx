import PhotoEditor from "../components/PhotoEditor";

export default function Editor() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Photo Editor</h1>
      <PhotoEditor />
    </div>
  );
}
