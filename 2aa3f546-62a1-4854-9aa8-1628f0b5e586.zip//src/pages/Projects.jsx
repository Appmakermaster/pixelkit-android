import { useNavigate } from "react-router-dom";
import "./Home.css";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="home">
      <h1>✨ PixelKit</h1>

      <p>Powerful • Simple • Fast</p>

      <p>
        Edit photos, create thumbnails, add text, stickers, effects and more.
      </p>

      <div className="home-buttons">
        <button onClick={() => navigate("/editor")}>✨ Start Editing</button>

        <button onClick={() => navigate("/projects")}>📁 My Projects</button>
      </div>
    </div>
  );
}
