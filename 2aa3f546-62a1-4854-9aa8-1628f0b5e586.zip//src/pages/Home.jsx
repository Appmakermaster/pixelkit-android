import { useNavigate } from "react-router-dom";
import "./Home.css";

export default function Home() {
  const navigate = useNavigate();

  return (
    <div className="home-page">
      {/* Hero */}
      <section className="hero-section">
        <div className="hero-content">
          <div className="hero-badge">✨ Powerful • Simple • Fast</div>

          <h1>
            Create Something
            <span> Amazing</span>
          </h1>

          <p>
            Edit photos, create thumbnails, add text, stickers, effects and much
            more with PixelKit.
          </p>

          <div className="hero-buttons">
            <button className="primary-btn" onClick={() => navigate("/editor")}>
              🚀 Start Editing
            </button>

            <button
              className="secondary-btn"
              onClick={() => navigate("/projects")}
            >
              📁 My Projects
            </button>
          </div>
        </div>

        <div className="hero-card">
          <div className="hero-card-top">
            <span>PixelKit</span>
            <span>✦</span>
          </div>

          <div className="preview-area">
            <div className="preview-circle">🎨</div>
            <h3>Your Creative Space</h3>
            <p>Turn your ideas into beautiful images.</p>
          </div>

          <div className="preview-tools">
            <span>✏️</span>
            <span>🖼️</span>
            <span>✨</span>
            <span>🔥</span>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="features-section">
        <h2>Everything You Need</h2>

        <p className="section-subtitle">
          Powerful editing tools in one simple app.
        </p>

        <div className="features-grid">
          <div className="feature-card">
            <div className="feature-icon">🖼️</div>
            <h3>Photo Editing</h3>
            <p>
              Upload photos and edit them with filters, brightness, contrast and
              more.
            </p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">✏️</div>
            <h3>Creative Tools</h3>
            <p>Add text, shapes, emojis, stickers, shadows and gradients.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">✨</div>
            <h3>AI Tools</h3>
            <p>Enhance images and create powerful AI-powered designs.</p>
          </div>

          <div className="feature-card">
            <div className="feature-icon">📤</div>
            <h3>Easy Export</h3>
            <p>Export your creations as PNG, JPG, WEBP and transparent PNG.</p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="cta-section">
        <h2>Ready to Create?</h2>

        <p>Start designing your next amazing image with PixelKit.</p>

        <button className="primary-btn" onClick={() => navigate("/editor")}>
          🚀 Open Editor
        </button>
      </section>
    </div>
  );
}
